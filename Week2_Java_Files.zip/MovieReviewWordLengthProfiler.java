import java.util.Scanner;

public class MovieReviewWordLengthProfiler {

    // Method to classify words by length
    public static void classifyWordLengths(String review) {
        String[] words = review.split("\\s+");

        int shortCount = 0;
        int mediumCount = 0;
        int longCount = 0;

        for (String word : words) {
            int length = word.length();

            if (length >= 1 && length <= 4) {
                shortCount++;
            } else if (length >= 5 && length <= 8) {
                mediumCount++;
            } else {
                longCount++;
            }
        }

        System.out.println("Short: " + shortCount
                + " | Medium: " + mediumCount
                + " | Long: " + longCount);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Movie Review: ");
        String review = sc.nextLine();

        classifyWordLengths(review);

        sc.close();
    }
}
