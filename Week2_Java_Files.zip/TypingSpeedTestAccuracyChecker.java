public class TypingSpeedTestAccuracyChecker {

    // Method to check typing accuracy
    public static void checkTypingAccuracy(String original, String typed) {
        int matchedCount = 0;
        int firstMismatch = -1;

        for (int i = 0; i < original.length(); i++) {
            if (original.charAt(i) == typed.charAt(i)) {
                matchedCount++;
            } else if (firstMismatch == -1) {
                firstMismatch = i;
            }
        }

        double accuracy =
                (matchedCount * 100.0) / original.length();

        System.out.printf("Matched: %d/%d | Accuracy: %.2f%%",
                matchedCount,
                original.length(),
                accuracy);

        if (firstMismatch == -1) {
            System.out.println(" | No Mismatches");
        } else {
            System.out.println(
                    " | First Mismatch at position "
                            + (firstMismatch + 1)
                            + " ('"
                            + original.charAt(firstMismatch)
                            + "' vs '"
                            + typed.charAt(firstMismatch)
                            + "')"
            );
        }
    }

    public static void main(String[] args) {
        String original1 = "hello world";
        String typed1 = "hello worlt";

        checkTypingAccuracy(original1, typed1);

        String original2 = "coding";
        String typed2 = "coding";

        checkTypingAccuracy(original2, typed2);
    }
}
